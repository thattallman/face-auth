const express = require("express");
const app = express();
const cors = require("cors");
app.use(cors());
const mongoose = require("mongoose");
const authRouter = require("./routes/authRoutes");
const bodyParser = require("body-parser");
mongoose
  .connect(
    `mongodb+srv://root:root@cluster0.f0pnhrv.mongodb.net/faceAuth?retryWrites=true&w=majority&appName=Cluster0`
  )
  .then(() => console.log("mongo db connected "));
app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use("/", authRouter);
// const PORT = 8000;
// app.listen(PORT, () => {
//   console.log("Server started at port", PORT);
// });
module.exports = app