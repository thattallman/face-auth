
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'thattallman10',
  applicationName: 'face-auth-serverless',
  appUid: 'cLXhhL9RD9yV471Twf',
  orgUid: '1d9bb6a2-2075-434c-a568-4beb0fdc70ae',
  deploymentUid: 'fa3a3e98-bb95-4096-bfa7-c1dc2be08561',
  serviceName: 'face-auth-serverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'face-auth-serverless-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}